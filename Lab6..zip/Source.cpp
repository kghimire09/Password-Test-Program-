#include <iostream>
#include <string>

using namespace std;

int main() {
	cout << "Welcome to the new Password System" << endl << endl;

	cout << "Your password must contain: " << endl; 
		cout << "1. 8 characters" << endl; 
		cout << "2. At least eight characters" << endl;
		cout << "3. At least one uppercase or lowercase character. " << endl; 
		cout << "4. At lease one number" << endl; 
		cout << "5. At one special character" << endl; 
		cout << "6. At lease one letter of the alphabet" << endl; 
		
	string password;
	string old_password;
	string new_password;
	string old_password_verification;

	bool valid_password = false;
	while (valid_password == false) {

		valid_password = true;

		cout << "Please create a password: ";

		getline(cin, password);
		new_password = password;

		if (password.length() < 8) {
			cout << "Your password must be at least 8 characters." << endl;
			valid_password = false;
		}

		int index = password.find_first_of("0123456789");
		if (index == -1) {
			cout << "Your password must include a number." << endl;
			valid_password = false;
		}

		bool special_character = false;
		for (char a : password) {
			if (ispunct(a)) {
				special_character = true;
				break;
			}
		}
		if (special_character == false) {
			cout << "Your password must include a special character." << endl;
			valid_password = false;
		}

		bool alphabet_character = false;
		for (char a : password) {
			if (isalpha(a)) {
				alphabet_character = true;
				break;
			}
		}
		if (alphabet_character == false) {
			cout << "Your password must include a letter of the alphabet." << endl;
			valid_password = false;
		}

		bool uppercase_letter = false;
		for (char a : password) {
			if (isupper(a)) {
				uppercase_letter = true;
				break;
			}
		}
		if (uppercase_letter == false) {
			cout << "Your password must include a uppercase letter." << endl;
			valid_password = false;
		}

		bool lowercase_letter = false;
		for (char a : password) {
			if (islower(a)) {
				lowercase_letter = true;
				break;
			}
		}
		if (lowercase_letter == false) {
			cout << "Your password must include a lowercase letter." << endl;
			valid_password = false;
		}

		bool whitespace_character = false;
		for (char a : password) {
			if (isspace(a)) {
				whitespace_character = true;
				break;
			}
		}
		if (whitespace_character == true) {
			cout << "Your password must not include spaces, tabs or returns." << endl;
			valid_password = false;
		}

		if (new_password == old_password) {
			cout << "Your new password cannot be the same as your old password." << endl;
			valid_password = false;
		}

		if (valid_password == false) {
			cout << endl << "Please enter a valid password." << endl;
		}

		char use_or_modify = 0;
		while (valid_password == true && (use_or_modify == !'u' || use_or_modify == !'m')) {

			cout << "Your password meets all requirements, would you like to save it or modify it? (u/m): ";
			cin >> use_or_modify;
			cin.ignore();
			switch (use_or_modify) {
			case 'u': {
				break;
			}
			case 'm': {
				valid_password = false;
				old_password = password;

				old_password_verification = '0';
				while (old_password_verification != old_password) {
					cout << "Please verify your old password: ";
					cin >> old_password_verification;
					cin.ignore();
					if (old_password_verification != old_password) {
						cout << "That does not match your old password." << endl;
					}
				}
				break;
			}
			default: {
				cout << "That is not a valid entry, enter 'u' or 'm': ";
				cin >> use_or_modify;
			}
			}
		}
	}
	cout << endl << "Your password is accepted." << endl;

	cout << endl;
	system("pause");
}